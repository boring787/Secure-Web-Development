<?php
// Include the initialization file which sets up the database connection and session
require_once "../init.php";

// Check if the "id" parameter is provided in the URL; if not, redirect to the homepage
if (!isset($_GET["id"])) {
    header("Location: index.php");
    exit();
}

// Prepare an SQL statement to fetch the post along with the username of the post creator
// This joins the "posts" and "users" tables and retrieves the post with the specified ID
$stmt = $pdo->prepare("SELECT posts.*, users.username FROM posts JOIN users ON posts.user_id = users.id WHERE posts.id = ?");
$stmt->execute([$_GET["id"]]);
$post = $stmt->fetch();

// If the post is not found, display an error message and stop execution
if (!$post) {
    echo "Post not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- The page title is set dynamically from the post title.
         ❌ UNSECURED OUTPUT (XSS): Directly outputting user-supplied content without sanitization can allow Cross-Site Scripting (XSS) -->
    <title><?= $post["title"] ?></title>
</head>

<body>
    <!-- Display the post title.
         ❌ XSS Vulnerability: Outputting the title directly may allow malicious scripts if not sanitized -->
    <h2><?= $post["title"] ?></h2>

    <!-- Link to the external CSS file for styling -->
    <link rel="stylesheet" href="../assets/css/styles.css">

    <!-- Display the username of the author and the creation date.
         ❌ XSS Possible: Outputting these values directly without sanitization could be unsafe if data is not properly validated -->
    <p>By <?= $post["username"] ?> on <?= $post["created_at"] ?></p>

    <!-- Check if the post has an image and display it if available -->
    <?php if ($post["image"]): ?>
        <img src="../uploads/<?= $post["image"] ?>" width="400">
    <?php endif; ?>

    <!-- Display the post content with newlines converted to HTML line breaks.
         ❌ XSS Vulnerability: Directly outputting content without sanitization could allow XSS attacks -->
    <p><?= nl2br($post["content"]) ?></p>

    <!-- A link to return to the homepage -->
    <a href="index.php">Back to Home</a>
</body>

</html>