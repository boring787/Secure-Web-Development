<?php
// Include the configuration and initialization file
require_once "../init.php";

// Check if the user is logged in by verifying the session variable "user_id"
// If the user is not logged in, redirect them to the login page and stop execution
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Check if the "id" parameter is set in the URL query string
// If not set, redirect the user back to the homepage and stop execution
if (!isset($_GET["id"])) {
    header("Location: index.php");
    exit();
}

// Get the post id from the URL and the user id from the session
$post_id = $_GET["id"];
$user_id = $_SESSION["user_id"];

// Fetch the post from the database that matches the given id and belongs to the current user
$stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ? AND user_id = ?");
$stmt->execute([$post_id, $user_id]);
$post = $stmt->fetch();

// Check if the post exists and belongs to the user
// If not, display an error message and stop execution
if (!$post) {
    echo "Unauthorized access or post not found.";
    exit();
}

// Prepare a statement to delete the post from the database
$stmt = $pdo->prepare("DELETE FROM posts WHERE id = ? AND user_id = ?");
// Execute the delete operation with the provided post id and user id
if ($stmt->execute([$post_id, $user_id])) {
    // If deletion is successful, redirect the user to the homepage
    header("Location: index.php");
    exit();
} else {
    // If deletion fails, display an error message
    echo "Failed to delete post.";
}
