<?php
// Include the initial configuration file
require_once "../init.php";

// Check if a user is logged in by verifying the session variable "user_id"
// If not logged in, redirect the user to the login page
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$error = ""; // Initialize error message variable

// Check if the form was submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Remove any extra spaces from the beginning and end of the title and content
    $title = trim($_POST["title"]);
    $content = trim($_POST["content"]);
    // Get the user id from the session
    $user_id = $_SESSION["user_id"];

    $image = null; // Initialize the image variable

    // Check if an image file was uploaded (the file name is not empty)
    if (!empty($_FILES["image"]["name"])) {
        // Define the directory where uploaded images will be stored
        $targetDir = "../uploads/";
        // Get the base file name from the uploaded file
        $fileName = basename($_FILES["image"]["name"]);
        // Convert the file extension to lowercase for consistency
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        // ✅ ALLOW ONLY SAFE FILE TYPES
        // Define the allowed image file extensions
        $allowedTypes = ["jpg", "jpeg", "png", "gif"];

        // Check if the uploaded file type is allowed
        if (in_array($fileType, $allowedTypes)) {
            // ✅ ENSURE FILE IS AN IMAGE
            // getimagesize() returns false if the file is not a valid image
            if (getimagesize($_FILES["image"]["tmp_name"])) {
                // ✅ RENAME FILE TO AVOID OVERWRITING
                // Create a unique new file name using uniqid() and current time
                $newFileName = uniqid() . "_" . time() . "." . $fileType;
                // Set the full path for the new file
                $targetFilePath = $targetDir . $newFileName;

                // ✅ MOVE FILE SAFELY
                // Move the uploaded file from the temporary location to the target directory
                if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
                    // Save the new file name in the $image variable to store it in the database later
                    $image = $newFileName;
                } else {
                    // Set an error message if the file could not be uploaded
                    $error = "Failed to upload file.";
                }
            } else {
                // Set an error message if the file is not a valid image
                $error = "Invalid file format.";
            }
        } else {
            // Set an error message if the file type is not allowed
            $error = "Invalid file type.";
        }
    }

    // ✅ STORE POST IN DATABASE IF NO ERROR
    // If there is no error, insert the post details into the database
    if (!$error) {
        // Prepare an SQL statement to insert the post data
        $stmt = $pdo->prepare("INSERT INTO posts (user_id, title, content, image) VALUES (?, ?, ?, ?)");
        // Execute the SQL statement with the provided data
        if ($stmt->execute([$user_id, $title, $content, $image])) {
            // If the post is successfully saved, redirect the user to the homepage
            header("Location: index.php");
            exit();
        } else {
            // Set an error message if the database operation failed
            $error = "Failed to create post.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Create Post</title>
    <!-- Link to the external CSS file for styling -->
    <link rel="stylesheet" href="../assets/css/styles.css">
    <script>
        // This function shows an alert with a message, if provided
        function showAlert(message) {
            if (message) {
                alert(message); // Display an alert box if there's an error message
            }
        }
    </script>
</head>

<body onload="showAlert('<?= $error ?>')"> <!-- When the page loads, check if there is an error message and display it -->
    <h2>Create New Post</h2>
    <!-- The form for creating a new post, using POST method and allowing file uploads -->
    <form method="POST" enctype="multipart/form-data">
        <!-- Input field for the post title -->
        <input type="text" name="title" placeholder="Post Title" required>
        <!-- Text area for the post content -->
        <textarea name="content" placeholder="Post Content" required></textarea>
        <!-- Input field for selecting an image file -->
        <input type="file" name="image">
        <!-- Submit button to publish the post -->
        <button type="submit">Publish</button>
    </form>
</body>

</html>