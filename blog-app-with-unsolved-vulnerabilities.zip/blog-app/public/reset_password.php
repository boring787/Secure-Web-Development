<?php
// Include the initialization file that sets up the database connection and starts the session
require_once "../init.php";

// Check if the form has been submitted using the POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if both the email and password fields are provided in the form submission
    if (!isset($_POST["email"]) || !isset($_POST["password"])) {
        // If any field is missing, show an alert and redirect back to the reset password page
        echo "<script>alert('Email or Password field is missing.'); window.location.href='reset_password.php';</script>";
        exit();
    }

    // Get the email and new password from the form input and remove extra spaces
    $email = trim($_POST["email"]);
    $new_password = trim($_POST["password"]);

    // Check if a user with the provided email exists in the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // If no user is found, alert the user and redirect back to the reset password page
    if (!$user) {
        echo "<script>alert('No account found with this email.'); window.location.href='reset_password.php';</script>";
        exit();
    }

    // Hash the new password using BCRYPT for secure storage in the database
    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

    // Update the user's password in the database with the hashed password
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
    if ($stmt->execute([$hashed_password, $email])) {
        // If the update is successful, alert the user and redirect to the login page
        echo "<script>alert('Password updated successfully. Please login with your new password.'); window.location.href='login.php';</script>";
    } else {
        // If the update fails, alert the user that resetting the password has failed
        echo "<script>alert('Failed to reset password. Try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Reset Password</title>
    <!-- Link to the external CSS file for styling the page -->
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>

<body>
    <h2>Reset Password</h2>
    <!-- Form for resetting the password -->
    <form method="POST">
        <!-- Input field for the user's email -->
        <input type="email" name="email" placeholder="Enter your email" required>
        <!-- Input field for the new password -->
        <input type="password" name="password" placeholder="Enter new password" required>
        <!-- Submit button to process the password reset -->
        <button type="submit">Reset</button>
    </form>
</body>

</html>