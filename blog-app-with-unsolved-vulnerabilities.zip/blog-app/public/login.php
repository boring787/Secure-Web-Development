<?php
// Include the configuration file to initialize the session and database connection
require_once "../init.php";

// Check if the form has been submitted using the POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the submitted email and password
    // ❌ Note: The email is not sanitized here, which can lead to SQL Injection vulnerabilities.
    $email = $_POST["email"];
    $password = $_POST["password"];

    // ❌ VULNERABLE SQL QUERY (First Attempt)
    // This query directly inserts user input into the SQL query, making it vulnerable to SQL Injection.
    $stmt = $pdo->query("SELECT * FROM users WHERE email = '$email' AND password = '$password'");
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // If no user is found with the insecure query, use a more secure approach as fallback
    if (!$user) {
        // ✅ Secure Query (Fallback)
        // Use a prepared statement to safely query the database using the provided email.
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verify the provided password against the hashed password stored in the database
        if ($user && password_verify($password, $user["password"])) {
            // Store user information in the session and redirect to the homepage
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            header("Location: index.php");
            exit();
        }
    }

    // If a user was found with the vulnerable query or after fallback verification
    if ($user) {
        // Store user data in session variables for later use (like maintaining login status)
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["username"] = $user["username"];
        header("Location: index.php");
        exit();
    } else {
        // If no user is found, alert the user with an "Invalid credentials" message.
        echo "<script>alert('Invalid credentials. Try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login</title>
    <!-- Link to an external CSS file for styling the page -->
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>

<body>
    <h2>Login</h2>
    <!-- Login form to capture user's email and password -->
    <form method="POST">
        <!-- Input for the user's email -->
        <input type="text" name="email" placeholder="Email" required>
        <!-- Input for the user's password -->
        <input type="password" name="password" placeholder="Password" required>
        <!-- Button to submit the login form -->
        <button type="submit">Login</button>
        <!-- Links for "Forgot Password" and "Register" for users who need them -->
        <p><a href="forgot_password.php">Forgot Password</a></p>
        <p><a href="register.php">Register</a></p>
    </form>
</body>

</html>