<?php
// Include the configuration file which sets up the database connection and other initial settings
require_once "../init.php";
// Include the mailer configuration that contains the function for sending emails
require_once "../config/mailer.php";

// Check if the form has been submitted using the POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Remove extra spaces from the beginning and end of the submitted email
    $email = trim($_POST["email"]);

    // Check if the email exists in the database
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // If the email is found in the database
    if ($user) {
        // Generate a random 6-digit One-Time Password (OTP)
        $otp = mt_rand(100000, 999999);
        // Set the expiration time for the OTP to 10 minutes from now
        $expires = date("Y-m-d H:i:s", strtotime("+10 minutes"));

        // Store the OTP and its expiration time in the database for the user with the provided email
        $stmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE email = ?");
        if ($stmt->execute([$otp, $expires, $email])) {
            // If OTP is stored successfully, send the OTP to the user's email using the sendOTP function
            if (sendOTP($email, $otp)) {
                // Redirect the user to the OTP verification page with the email passed as a parameter
                header("Location: verify_otp.php?email=" . urlencode($email));
                exit();
            } else {
                // Display an error message if the email could not be sent
                echo "Failed to send OTP.";
            }
        } else {
            // Display an error message if storing the OTP in the database fails
            echo "Error storing OTP.";
        }
    } else {
        // Display a message if the email is not found in the database
        echo "Email not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Forgot Password</title>
    <!-- Link to the external CSS file for page styling -->
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>

<body>
    <h2>Forgot Password</h2>
    <!-- Form to allow users to enter their email address for password reset -->
    <form method="POST">
        <!-- Email input field; requires a valid email format -->
        <input type="email" name="email" placeholder="Enter your email" required>
        <!-- Button to submit the form and send the OTP -->
        <button type="submit">Send OTP</button>
    </form>
</body>

</html>