<?php
// Include the initialization file that sets up the database connection and starts the session
require_once "../init.php";

// Check if the "email" parameter exists in the URL query string
// If not, redirect the user to the "forgot_password.php" page
if (!isset($_GET["email"])) {
    header("Location: forgot_password.php");
    exit();
}

// Get the email from the URL query string
$email = $_GET["email"];

// Check if the form has been submitted using the POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the OTP (One-Time Password) entered by the user and remove any extra spaces
    $otp = trim($_POST["otp"]);

    // Fetch the stored OTP and its expiration time from the database for the given email
    $stmt = $pdo->prepare("SELECT reset_token, reset_expires FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Fetch the current server time from the database to compare against the expiration time
    $stmt_now = $pdo->query("SELECT NOW()");
    $current_time_row = $stmt_now->fetch();
    $current_time = $current_time_row[0]; // Get the current time as a string

    // For debugging purposes, display the stored OTP, entered OTP, expiration time, and current server time
    if ($user) {
        echo "Stored OTP: " . htmlspecialchars($user['reset_token']) . "<br>";
        echo "Entered OTP: " . htmlspecialchars($otp) . "<br>";
        echo "Reset Expires: " . htmlspecialchars($user['reset_expires']) . "<br>";
        echo "Current Server Time: " . htmlspecialchars($current_time) . "<br>";
    } else {
        // If no user is found with the provided email, show an error message and stop execution
        echo "User not found.";
        exit();
    }

    // Verify that the OTP is valid and that it has not expired
    // This query checks that the provided OTP matches the stored one and that the expiration time is still in the future
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND reset_token = ? AND reset_expires > NOW()");
    $stmt->execute([$email, $otp]);
    $valid_user = $stmt->fetch();

    if ($valid_user) {
        // If the OTP is valid and not expired, clear the OTP and its expiration time from the database
        $stmt = $pdo->prepare("UPDATE users SET reset_token = NULL, reset_expires = NULL WHERE email = ?");
        $stmt->execute([$email]);

        // Redirect the user to the reset password page, passing the email in the URL
        header("Location: reset_password.php?email=" . urlencode($email));
        exit();
    } else {
        // If the OTP is invalid or has expired, display an error message to the user
        echo "❌ Invalid or expired OTP. Please request a new one.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Verify OTP</title>
</head>

<body>
    <h2>Enter OTP</h2>
    <!-- Form for the user to enter the OTP -->
    <form method="POST">
        <!-- Input field for the OTP -->
        <input type="text" name="otp" placeholder="Enter OTP" required>
        <!-- Button to submit the form and verify the OTP -->
        <button type="submit">Verify</button>
    </form>
</body>

</html>