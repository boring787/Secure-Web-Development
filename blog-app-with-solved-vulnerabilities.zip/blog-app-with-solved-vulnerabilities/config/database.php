<?php
$host = "localhost";
$db_name = "blog_app";
$username = "root"; // Change if needed
$password = ""; // Change if needed

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Force MySQL timezone to match PHP timezone
    $pdo->exec("SET time_zone = '+05:00'"); // Adjust based on your timezone

} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

//database mysql connection file
