<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';

function sendOTP($email, $otp)
{
    $mail = new PHPMailer(true);

    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Change this for different email providers
        $mail->SMTPAuth = true;
        $mail->Username = 'zafardeveloper8@gmail.com'; // Replace with your email
        $mail->Password = 'nhgttjjspevpcufw'; // Use App Password if 2FA is enabled
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Email Settings
        $mail->setFrom('zafardeveloper8@gmail.com', 'Your Blog');
        $mail->addAddress($email);
        $mail->Subject = 'Your Password Reset OTP';
        $mail->Body = "Your OTP for password reset is: $otp\nThis OTP is valid for 10 minutes.";

        // Send Email
        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}


//file for sending verification otp for forgget password feature