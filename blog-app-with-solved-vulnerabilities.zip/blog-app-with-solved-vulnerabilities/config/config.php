<?php
define("WEATHER_API_KEY", "179170851af6f7ce9f2cd4a9a01468dc"); // Replace with your OpenWeatherMap API Key

//weather api to get weather from open weather website