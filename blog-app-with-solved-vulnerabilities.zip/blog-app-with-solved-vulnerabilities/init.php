<?php
session_start();
require_once "config/database.php";

// Set the correct timezone (adjust if needed)
date_default_timezone_set("Asia/Karachi"); // Change this based on your timezone
