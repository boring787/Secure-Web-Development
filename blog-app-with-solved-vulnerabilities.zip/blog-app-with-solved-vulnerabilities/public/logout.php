<?php
session_start();
session_destroy();
header("Location: login.php");
exit();

// is user is in dashboard this button send user to login page