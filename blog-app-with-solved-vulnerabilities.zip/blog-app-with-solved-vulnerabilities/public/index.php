<?php
// Include the configuration file which sets up the database connection and session management
require_once "../init.php";
// Include the configuration file that holds the API key and other settings for the weather service
require_once "../config/config.php";

// Fetch all blog posts along with the username of the user who created each post
// This SQL query joins the "posts" and "users" tables, ordering the posts by creation date (newest first)
$stmt = $pdo->query("SELECT posts.*, users.username FROM posts 
                     JOIN users ON posts.user_id = users.id 
                     ORDER BY posts.created_at DESC");
// Retrieve all the posts into an array
$posts = $stmt->fetchAll();

// Get the city from the URL's query string (user input) if available, otherwise default to "New York"
$city = isset($_GET["city"]) ? trim($_GET["city"]) : "New York";

// Build the OpenWeatherMap API URL using the city name and your API key, with units set to metric (°C)
$weather_url = "http://api.openweathermap.org/data/2.5/weather?q=" . urlencode($city) . "&units=metric&appid=" . WEATHER_API_KEY;

// Fetch weather data from the OpenWeatherMap API using the URL
$weather_data = file_get_contents($weather_url);
// Decode the JSON response into a PHP array
$weather = json_decode($weather_data, true);

// Extract weather details from the API response:
// Temperature: if available, otherwise show "N/A"
$temp = isset($weather["main"]["temp"]) ? $weather["main"]["temp"] : "N/A";
// Weather description: get the first description and capitalize the first letter, or use "Unknown" if not available
$weather_desc = isset($weather["weather"][0]["description"]) ? ucfirst($weather["weather"][0]["description"]) : "Unknown";
// Weather icon code: if available, otherwise empty
$icon = isset($weather["weather"][0]["icon"]) ? $weather["weather"][0]["icon"] : "";
// Construct the URL to display the weather icon image if an icon code is available
$icon_url = $icon ? "http://openweathermap.org/img/wn/" . $icon . "@2x.png" : "";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Blog Home</title>
    <!-- Link to external CSS file for styling the page -->
    <link rel="stylesheet" href="../assets/css/indexpage.css">
    <!-- Include a Google font for better typography -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@400;600;700&display=swap">
</head>

<body>
    <h2>Welcome to the Blog</h2>

    <!-- Display navigation links based on whether the user is logged in -->
    <?php if (isset($_SESSION["username"])): ?>
        <!-- If the user is logged in, show a welcome message and links to logout and create a new post -->
        <p>Welcome, <?= htmlspecialchars($_SESSION["username"]) ?> |
            <a href="logout.php">Logout</a> |
            <a href="create_post.php">Create Post</a>
        </p>
    <?php else: ?>
        <!-- If not logged in, show links to the login and registration pages -->
        <p><a href="login.php">Login</a> | <a href="register.php">Register</a></p>
    <?php endif; ?>

    <!-- Weather Section -->
    <h3>Check Weather</h3>
    <!-- Form for users to enter a city name to get the weather information -->
    <form method="GET">
        <input type="text" name="city" placeholder="Enter city name" required>
        <button type="submit">Get Weather</button>
    </form>

    <!-- Display the weather information for the selected city -->
    <h3>Weather in <?= htmlspecialchars($city) ?>:</h3>
    <?php if ($icon): ?>
        <!-- If an icon is available, display the weather icon image -->
        <img src="<?= $icon_url ?>" alt="Weather Icon">
    <?php endif; ?>
    <!-- Display the temperature and weather condition -->
    <p>Temperature: <?= htmlspecialchars($temp) ?>°C</p>
    <p>Condition: <?= htmlspecialchars($weather_desc) ?></p>

    <!-- Blog Posts Section -->
    <h3>Recent Posts</h3>
    <?php if (count($posts) > 0): ?>
        <!-- Loop through each post and display its details -->
        <?php foreach ($posts as $post): ?>
            <div class="post">
                <!-- If the post has an image, display the image -->
                <?php if ($post["image"]): ?>
                    <img src="../uploads/<?= htmlspecialchars($post["image"]) ?>" alt="Blog Image">
                <?php endif; ?>

                <!-- Display the title of the post -->
                <h4><?= htmlspecialchars($post["title"]) ?></h4>
                <!-- Display the username of the post creator and the creation date -->
                <small>By <?= htmlspecialchars($post["username"]) ?> | <?= $post["created_at"] ?></small>

                <!-- Show a snippet of the post content (first 150 characters) with line breaks preserved -->
                <p><?= nl2br(htmlspecialchars(substr($post["content"], 0, 150))) ?>...</p>

                <div class="post-actions">
                    <!-- Link to view the full post -->
                    <a href="view_post.php?id=<?= $post["id"] ?>" class="read-more">Read More</a>

                    <!-- Show Edit/Delete options only for the owner of the post -->
                    <?php if (isset($_SESSION["user_id"]) && $_SESSION["user_id"] == $post["user_id"]): ?>
                        <div class="action-buttons">
                            <!-- Link to edit the post -->
                            <a href="edit_post.php?id=<?= $post["id"] ?>" class="edit-btn">Edit</a>
                            <!-- Link to delete the post; confirmation prompt before deletion -->
                            <a href="delete_post.php?id=<?= $post["id"] ?>" class="delete-btn" onclick="return confirm('Are you sure?')">Delete</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

    <?php else: ?>
        <!-- If there are no posts available, display a message -->
        <p>No posts available.</p>
    <?php endif; ?>

</body>

</html>