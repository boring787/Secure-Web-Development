<?php
// Include the initialization file that sets up the database connection and starts the session
require_once "../init.php"; // Ensure this file is correctly included

$error = ""; // Initialize an empty error message variable

// Check if the form has been submitted using the POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and remove extra spaces from the username and email input values
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    // Get the password as provided by the user (do not trim passwords)
    $password = $_POST["password"];

    // ✅ ENFORCE STRONG PASSWORD POLICY
    // This regular expression checks that the password:
    // - Has at least 8 characters
    // - Contains at least one uppercase letter
    // - Contains at least one lowercase letter
    // - Contains at least one number
    // - Contains at least one special character (e.g., @$!%*#?&)
    if (!preg_match("/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/", $password)) {
        $error = "Password must be at least 8 characters long, include at least one uppercase letter, one lowercase letter, one number, and one special character.";
    } else {
        // Hash the password using BCRYPT for secure storage in the database
        $password_hash = password_hash($password, PASSWORD_BCRYPT);

        try {
            // Prepare an SQL statement to insert the new user into the users table
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            // Execute the statement with the provided username, email, and hashed password
            if ($stmt->execute([$username, $email, $password_hash])) {
                // If registration is successful, redirect the user to the login page
                header("Location: login.php");
                exit();
            } else {
                // If the insert fails, set an error message
                $error = "Registration failed.";
            }
        } catch (PDOException $e) {
            // Catch any PDO exception (database error) and store the error message
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Register</title>
    <!-- Link to the external CSS file for styling the page -->
    <link rel="stylesheet" href="../assets/css/styles.css">
    <script>
        // Function to display an alert with an error message when the page loads
        function showAlert(message) {
            if (message) {
                alert(message); // Display alert if there's an error message
            }
        }
    </script>
</head>

<!-- Call the showAlert function on page load, passing in the error message if any -->

<body onload="showAlert('<?= $error ?>')">
    <h2>Register</h2>
    <!-- Registration form to collect username, email, and password -->
    <form method="POST">
        <!-- Input field for the username -->
        <input type="text" name="username" placeholder="Username" required>
        <!-- Input field for the email; HTML5 ensures proper email format -->
        <input type="email" name="email" placeholder="Email" required>
        <!-- Input field for the password -->
        <input type="password" name="password" placeholder="Password" required>
        <!-- Submit button to register the new account -->
        <button type="submit">Register</button>
        <!-- Link to the login page for users who already have an account -->
        <p><a href="login.php">Login</a></p>
    </form>
</body>

</html>