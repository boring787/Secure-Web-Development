<?php
// Include the initial configuration file
require_once "../init.php";

// Check if a user is logged in by verifying the session variable "user_id"
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$error = ""; // Initialize error message variable

// Check if the form was submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Securely process the input to prevent SQL Injection and XSS
    $title = htmlspecialchars(trim($_POST["title"]), ENT_QUOTES, 'UTF-8');
    $content = htmlspecialchars(trim($_POST["content"]), ENT_QUOTES, 'UTF-8');
    $user_id = $_SESSION["user_id"];

    $image = null; // Initialize the image variable

    // Check if an image file was uploaded
    if (!empty($_FILES["image"]["name"])) {
        $targetDir = "../uploads/";
        $fileName = basename($_FILES["image"]["name"]);
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        // ✅ ALLOW ONLY SAFE FILE TYPES
        $allowedTypes = ["jpg", "jpeg", "png", "gif"];

        // Validate file type and ensure it's an actual image
        if (in_array($fileType, $allowedTypes) && getimagesize($_FILES["image"]["tmp_name"])) {
            // ✅ RENAME FILE TO AVOID OVERWRITING
            $newFileName = uniqid() . "_" . time() . "." . $fileType;
            $targetFilePath = $targetDir . $newFileName;

            // ✅ MOVE FILE SAFELY
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
                $image = $newFileName;
            } else {
                $error = "Failed to upload file.";
            }
        } else {
            $error = "Invalid file type.";
        }
    }

    // ✅ STORE POST IN DATABASE IF NO ERROR
    if (!$error) {
        try {
            // Use prepared statements to prevent SQL Injection
            $stmt = $pdo->prepare("INSERT INTO posts (user_id, title, content, image) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$user_id, $title, $content, $image])) {
                header("Location: index.php");
                exit();
            } else {
                $error = "Failed to create post.";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Create Post</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <script>
        function showAlert(message) {
            if (message) {
                alert(message);
            }
        }
    </script>
</head>

<body onload="showAlert('<?= $error ?>')">
    <h2>Create New Post</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="title" placeholder="Post Title" required>
        <textarea name="content" placeholder="Post Content" required></textarea>
        <input type="file" name="image">
        <button type="submit">Publish</button>
    </form>
</body>

</html>