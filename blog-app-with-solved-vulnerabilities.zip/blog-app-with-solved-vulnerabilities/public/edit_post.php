<?php
// Include the configuration and initialization file which sets up the database connection and session
require_once "../init.php";

// Check if the user is logged in by verifying the session variable "user_id"
// If the user is not logged in, redirect them to the login page and stop further execution
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Check if the "id" parameter exists in the URL's query string
// If it is not present, redirect the user to the homepage
if (!isset($_GET["id"])) {
    header("Location: index.php");
    exit();
}

// Retrieve the post ID from the URL and the user ID from the session
$post_id = $_GET["id"];
$user_id = $_SESSION["user_id"];

// Fetch the post from the database that belongs to the logged-in user and has the given ID
$stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ? AND user_id = ?");
$stmt->execute([$post_id, $user_id]);
$post = $stmt->fetch();

// If the post is not found or the user is not authorized to edit it, display an error message and stop execution
if (!$post) {
    echo "Unauthorized access or post not found.";
    exit();
}

// Check if the form has been submitted using the POST method for updating the post
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Remove any extra spaces from the beginning and end of the title and content inputs
    $title = trim($_POST["title"]);
    $content = trim($_POST["content"]);

    // Check if a new image file is uploaded with the form
    if (!empty($_FILES["image"]["name"])) {
        // Define the directory where uploaded images will be stored
        $targetDir = "../uploads/";
        // Get the base file name of the uploaded image
        $image = basename($_FILES["image"]["name"]);
        // Create the full path where the image will be saved
        $targetFilePath = $targetDir . $image;

        // Validate the image file type by getting its extension
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
        // Define a list of allowed image file types
        $allowedTypes = ["jpg", "jpeg", "png", "gif"];

        // Check if the uploaded file's type is in the allowed list
        if (in_array($fileType, $allowedTypes)) {
            // Move the uploaded image file from its temporary location to the defined uploads directory
            move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath);
        } else {
            // If the file type is not allowed, display an error message and stop execution
            echo "Invalid file type.";
            exit();
        }
    } else {
        // If no new image was uploaded, keep the current image from the post
        $image = $post["image"];
    }

    // Prepare an SQL statement to update the post's title, content, and image in the database
    $stmt = $pdo->prepare("UPDATE posts SET title = ?, content = ?, image = ? WHERE id = ? AND user_id = ?");
    // Execute the update statement with the provided data
    if ($stmt->execute([$title, $content, $image, $post_id, $user_id])) {
        // If the update is successful, redirect the user back to the homepage
        header("Location: index.php");
        exit();
    } else {
        // If the update fails, display an error message
        echo "Failed to update post.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Edit Post</title>
    <!-- Link to the external CSS file for styling the page -->
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>

<body>
    <h2>Edit Post</h2>
    <!-- Form for editing the post, uses POST method and allows file uploads -->
    <form method="POST" enctype="multipart/form-data">
        <!-- Input field for editing the post title; pre-filled with the current title -->
        <input type="text" name="title" value="<?= htmlspecialchars($post['title']) ?>" required>
        <!-- Text area for editing the post content; pre-filled with the current content -->
        <textarea name="content" required><?= htmlspecialchars($post['content']) ?></textarea>
        <!-- Input field for uploading a new image (optional) -->
        <input type="file" name="image">
        <!-- Submit button to update the post -->
        <button type="submit">Update Post</button>
    </form>
</body>

</html>