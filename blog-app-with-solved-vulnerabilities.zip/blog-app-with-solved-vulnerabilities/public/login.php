<?php
// Include the configuration file to initialize the session and database connection
require_once "../init.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Securely get the submitted email and password
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    try {
        // ✅ SECURE: Use a prepared statement to prevent SQL Injection
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // ✅ Verify the password securely
        if ($user && password_verify($password, $user["password"])) {
            // Store user information in session
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            header("Location: index.php");
            exit();
        } else {
            $error = "Invalid credentials. Try again.";
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <script>
        function showAlert(message) {
            if (message) {
                alert(message);
            }
        }
    </script>
</head>

<body onload="showAlert('<?= isset($error) ? $error : "" ?>')">
    <h2>Login</h2>
    <form method="POST">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
        <p><a href="forgot_password.php">Forgot Password</a></p>
        <p><a href="register.php">Register</a></p>
    </form>
</body>

</html>